<?php
$lang['dashboard'] = 'Tableau de bord';
$lang['users'] = 'Utilisateurs';
$lang['logout'] = 'Déconnexion';
